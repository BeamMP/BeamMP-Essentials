local M = {}
print("AntiAFK Initializing...")



local camera = extensions.core_camera
local timer = 0
local lastPositions = {}
local lastCameraRotationX = 0
local lastCameraRotationY = 0



local function onUpdate(deltaTime)
	timer = timer + deltaTime
	if timer >= 1 then
		timer = 0
		for i = 0, be:getObjectCount() - 1 do
			local veh = be:getObject(i)
			local gameVehicleID = veh:getID()
			if MPVehicleGE.isOwn(gameVehicleID) then
				local pos = veh:getPosition()
				local lastPos = lastPositions[gameVehicleID] or {x = 0, y = 0, z = 0}
				local xOffset = math.abs(lastPos.x - pos.x)
				local yOffset = math.abs(lastPos.y - pos.y)
				local zOffset = math.abs(lastPos.z - pos.z)
				if xOffset > 0.05 or yOffset > 0.05 or xOffset > 0.05 then
					lastPositions[gameVehicleID] = vec3(pos.x, pos.y, pos.z)
					TriggerServerEvent("onPlayerMoved", "m")
				end
			end
		end
		
		local currVehicle = be:getPlayerVehicle(0)
		if currVehicle then
			local cameraData = camera.getCameraDataById(currVehicle:getID())
			local cameraRot = cameraData[camera.getActiveCamName()]
			if lastCameraRotationX ~= cameraRot.x or lastCameraRotationY ~= cameraRot.y then
				lastCameraRotationX = cameraRot.x
				lastCameraRotationY = cameraRot.y
				TriggerServerEvent("onPlayerMoved", "m")
				print("camera moved")
			end
		end
	end
end



local function onVehicleSwitched()
	TriggerServerEvent("onPlayerMoved", "m")
end



M.onVehicleSwitched = onVehicleSwitched
M.onUpdate = onUpdate



return M