load("AntiAFK")
registerCoreModule("AntiAFK")