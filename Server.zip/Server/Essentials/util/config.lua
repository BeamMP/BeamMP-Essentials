-- By jojos38

local function getConfig(pluginName)
	local configFile = readJsonFile(pluginPath..pluginName.."/config.json")
	if configFile then
		log('i', "Loaded config file for plugin "..pluginName)
		return configFile
	else
		log('w', "No config file found for plugin "..pluginName)
		return {}
	end
end



local function saveSetting()
end



return {
	getConfig = getConfig
}