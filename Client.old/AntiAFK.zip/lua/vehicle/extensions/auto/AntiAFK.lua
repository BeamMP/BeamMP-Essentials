--[[
	All content by jojos38
	You are not allowed to or use this code
--]]


-- =================== VARIABLES ===================
local M = {}
local timer = 0
local lastElectrics = {}
local lastTrigger = os.time()
local electricsToCheck = {
	"brake_input",
	"clutch_input",
	"hazard_enabled",
	"horn",
	"lightbar",
	"parkingbrake_input",
	"lights",
	"throttle_input",
	"steering_input",
	"signal_left_input",
	"signal_right_input"
}
-- =================== VARIABLES ===================



local function triggerMoved()
	local currTime = os.time()
	if currTime - lastTrigger > 2 then
		print("triggerVE")
		obj:queueGameEngineLua('TriggerServerEvent("onPlayerMoved", "m")')
		lastTrigger = currTime
	end
end



local function updateGFX(deltaTime)
	if v.mpVehicleType == "L" then -- If own the vehicle
		timer = timer + deltaTime
		if timer >= 0.25 then
			timer = 0
			-- Check electrics
			if not electrics.values then return end
			for _, toCheck in pairs(electricsToCheck) do
				local value = electrics.values[toCheck]
				if value then
					if lastElectrics[toCheck] ~= value then
						obj:queueGameEngineLua('AntiAFK.triggerMoved()')
						lastElectrics[toCheck] = value
						break
					end
				end
			end
		end
	end
end



M.updateGFX = updateGFX


return M