

--[[
	All content by jojos38
	You are not allowed to or use this code
--]]


-- =================== VARIABLES ===================
print("AntiAFK Initializing...")
local M = {}
local camera = extensions.core_camera
local timer = 0
local lastPositions = {}
local lastCameraRotationX = 0
local lastCameraRotationY = 0
local lastTrigger = os.time()
-- =================== VARIABLES ===================



local function triggerMoved()
	local currTime = os.time()
	if currTime - lastTrigger > 2 then
		print("triggerGE")
		TriggerServerEvent("onPlayerMoved", "m")
		lastTrigger = currTime
	end
end



local function onUpdate(deltaTime)
	timer = timer + deltaTime
	if timer >= 1 then
		timer = 0
		for i = 0, be:getObjectCount() - 1 do
			local veh = be:getObject(i)
			local gameVehicleID = veh:getID()
			if MPVehicleGE.isOwn(gameVehicleID) then
				-- Check position
				local pos = veh:getPosition()
				local lastPos = lastPositions[gameVehicleID] or {x = 0, y = 0, z = 0}
				local xOffset = math.abs(lastPos.x - pos.x)
				local yOffset = math.abs(lastPos.y - pos.y)
				local zOffset = math.abs(lastPos.z - pos.z)
				if xOffset > 0.04 or yOffset > 0.04 or xOffset > 0.04 then
					lastPositions[gameVehicleID] = vec3(pos.x, pos.y, pos.z)
					triggerMoved()
				end
			end
		end
	end
end



local function onVehicleSwitched()
	triggerMoved()
end



M.onVehicleSwitched = onVehicleSwitched
M.onUpdate = onUpdate
M.triggerMoved = triggerMoved



return M